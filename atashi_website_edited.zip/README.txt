Atashi Private Limited — Website
Files:
- index.html         (main website)
- thankyou.html      (redirect after form submit)
How to use:
1. Open index.html in a browser (on phone or desktop) to preview locally.
2. Form submissions are sent using FormSubmit.co to jyoti27002@gmail.com (no server required).
   - If you prefer Formspree, replace the form 'action' attribute in index.html with your Formspree endpoint.
3. To publish the site: upload all files to any static host (Netlify, Vercel, GitHub Pages, etc.).
Edit social links in index.html (search for id="insta", id="linkedin", id="twitter").
